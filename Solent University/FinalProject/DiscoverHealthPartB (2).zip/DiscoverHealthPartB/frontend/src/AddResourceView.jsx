import { useState } from 'react';

/**
 * AddResourceView provides a form to submit a new healthcare resource.
 */
export default function AddResourceView() {
  // form state stores all input values
  const [form, setForm] = useState({
    name: '', category: '', country: '', region: '',
    lat: '', lon: '', description: ''
  });
  // message and error states show success or error feedback
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  // Updates form state when any input changes
  function handleChange(e) {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  }

  // Handles form submission
  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setMessage('');

    // Validate that all fields are filled
    for (const key of Object.keys(form)) {
      if (!form[key].trim()) {
        setError('All fields are required.');
        return;
      }
    }

    try {
      // Send the data to the Express API; convert lat/lon strings to numbers
      const res = await fetch('http://localhost:3000/api/resources', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          lat: parseFloat(form.lat),
          lon: parseFloat(form.lon)
        })
      });
      const data = await res.json();
      if (res.ok) {
        setMessage(`Resource added with ID ${data.id}`);
        // Reset the form values
        setForm({
          name: '', category: '', country: '', region: '',
          lat: '', lon: '', description: ''
        });
      } else {
        setError(data.error || 'Failed to add resource.');
      }
    } catch (err) {
      console.error(err);
      setError('An unexpected error occurred.');
    }
  }

  return (
    <div>
      <h2>Add a New Resource</h2>
      {/* Display errors and success messages */}
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {message && <p style={{ color: 'green' }}>{message}</p>}
      <form onSubmit={handleSubmit}>
        {/* Each input/textarea is controlled by form state via name=... */}
        <div style={{ marginBottom: '8px' }}>
          <input name="name" value={form.name} onChange={handleChange} placeholder="Name" />
        </div>
        <div style={{ marginBottom: '8px' }}>
          <input name="category" value={form.category} onChange={handleChange} placeholder="Category" />
        </div>
        <div style={{ marginBottom: '8px' }}>
          <input name="country" value={form.country} onChange={handleChange} placeholder="Country" />
        </div>
        <div style={{ marginBottom: '8px' }}>
          <input name="region" value={form.region} onChange={handleChange} placeholder="Region" />
        </div>
        <div style={{ marginBottom: '8px' }}>
          <input name="lat" value={form.lat} onChange={handleChange} placeholder="Latitude" type="number" step="0.0001" />
        </div>
        <div style={{ marginBottom: '8px' }}>
          <input name="lon" value={form.lon} onChange={handleChange} placeholder="Longitude" type="number" step="0.0001" />
        </div>
        <div style={{ marginBottom: '8px' }}>
          <textarea name="description" value={form.description} onChange={handleChange} placeholder="Description" rows="3" />
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}
